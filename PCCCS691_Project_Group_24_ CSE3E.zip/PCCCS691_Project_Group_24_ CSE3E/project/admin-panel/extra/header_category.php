<body>
<div class="container">
    <div class = "header-container">
        <div class="header">
            <div class="name-details">
                <h3>Inventory Control System [ made by Subhronil Saha, 70 | Suman Saha, 71 | Sutapa Banik, 72 | CSE 3E ]</h3>
            </div>
            <ul class="navbar">
                <li><a href="../index.php">Modules</a></li>
                <li><a href="get_category.php">View Categories</a></li>
                <li><a href="add_category.php">Add Category</a></li>
                <li><a href="../login_do.php?logout=true">Logout</a></li>
            </ul>
        </div>
    </div>